# Promos — I Married a Broken Soldier. He was a Duke
Model: `heuristic` · candidates: 96 · top list: 13

## #1 · E01-A1-P1 · score 87.0 · 38s · multi
- **Segments:** Ep 1 00:39.10–00:50.40 + Ep 1 01:51.10–02:17.50
- **Hook (betrayal):** Lady In Gold Gown: "Because he is marrying me."
- **Cliffhanger:** Solemn low-pitched string drone swells to an ominous cliffhanger peak.
- **Why:** Cold-opens on the episode's biggest beat, then jumps to its closing cliffhanger.
- **Scores:** hook 5.0/5 · cliffhanger 5.0/5 · standalone 3.0/5

<details><summary>Transcript</summary>

```
(00:39.10) LADY IN GOLD GOWN: Because he is marrying me.
(00:41.70) LADY JULIANA: No...
(00:46.80) LADY JULIANA: You knew this before I walked through those doors!
--- cut ---
(01:51.10) LADY IN GOLD GOWN: I am the daughter they choose.
(01:53.30) MATRIARCH: Clarissa is the jewel of this family.
(01:57.00) LADY JULIANA: So that is what I was worth to you?
(01:59.80) THE FORMER GROOM: You have nothing to offer me anymore.
(02:04.20) THE FORMER GROOM: I cannot marry a woman of such plainness and low value...
(02:08.50) THE FORMER GROOM: ...when Clarissa is the true jewel of the county.
(02:11.30) [ACTION] Juliana's hand clenches fiercely into the folds of her mother's silk bridal gown, knuckles whitening with suppressed fury.
(02:13.80) [ACTION] Juliana breathes through the agony, refusing to break down further in front of the congregation.
(02:15.00) [SFX] Solemn low-pitched string drone swells to an ominous cliffhanger peak.
```
</details>

## #2 · E21-A1-P1 · score 84.5 · 32s · single
- **Segments:** Ep 21 00:03.50–00:35.80
- **Hook (threat):** Prudence: "Lady Juliana! Please! You have to help me, Toby is dying!"
- **Cliffhanger:** Prudence: "He is only seven! If you do not come, he will die! You are his only hope, Lady Juliana!"
- **Why:** Opens on a threat beat and cuts on an unresolved dialogue moment.
- **Scores:** hook 5.0/5 · cliffhanger 4.0/5 · standalone 4.0/5

<details><summary>Transcript</summary>

```
(00:03.50) [SFX] A loud wooden slam as the heavy double barn doors violently fly open.
(00:04.20) PRUDENCE: Lady Juliana! Please! You have to help me, Toby is dying!
(00:08.20) [ACTION] Lady Juliana hurries over, placing her bandaged hands reassuringly on Prudence's trembling shoulders.
(00:08.50) LADY JULIANA: Oh dear. Breathe. Tell me what has happened.
(00:11.20) PRUDENCE: My little brother Toby... his chest is burning! He cannot breathe!
(00:15.00) LADY JULIANA: Tell me what the apothecary said. Did he not give you medicine?
(00:18.20) PRUDENCE: He shut the door in my face because we have no silver!
(00:21.80) PRUDENCE: The manor doctor laughed! He said village boys are not worth his time!
(00:25.10) LADY JULIANA: We have no clinic now.
(00:27.50) LADY JULIANA: Our cottage is ashes. I have nothing left but this coltsfoot.
(00:31.00) [ACTION] Prudence drops desperately to her knees onto the hay-strewn barn floor, clasping her hands in tearful supplication.
(00:31.00) PRUDENCE: He is only seven! If you do not come, he will die! You are his only hope, Lady Juliana!
```
</details>

## #3 · E15-A1-P1 · score 83.1 · 32s · multi
- **Segments:** Ep 15 00:47.40–00:56.50 + Ep 15 01:03.50–01:26.00
- **Hook (violence):** The Thug with Cap violently shoves Juliana back with both hands; she cries out as she los…
- **Cliffhanger:** Tense, low dramatic cello swell holding into an abrupt cliffhanger cut.
- **Why:** Cold-opens on the episode's biggest beat, then jumps to its closing cliffhanger.
- **Scores:** hook 4.0/5 · cliffhanger 5.0/5 · standalone 4.0/5

<details><summary>Transcript</summary>

```
(00:47.40) [ACTION] The Thug with Cap violently shoves Juliana back with both hands; she cries out as she loses her balance and crashes hard onto the wet stone path.
(00:47.80) JULIANA: Ah!
(00:50.00) [ACTION] Juliana crawls forward on her elbows; fresh crimson blood seeps profusely through her white gauze bandages as she reaches for the ruined blossoms.
(00:53.50) JULIANA: My mother's plants...
--- cut ---
(01:03.50) [ACTION] Alexander storms forward with lethal intensity, dark hair flying, breath misting in the cold, radiating untamed rage.
(01:10.50) JULIANA: Alexander...
(01:16.00) [ACTION] Alexander places himself directly between Juliana and the three thugs, staring them down with cold, deadly intent.
(01:19.00) THUG WITH CAP: What? You want to fight us, veteran?
(01:24.00) [SFX] Tense, low dramatic cello swell holding into an abrupt cliffhanger cut.
```
</details>

## #4 · E24-A1-P1 · score 74.7 · 36s · multi
- **Segments:** Ep 24 00:35.00–00:45.50 + Ep 24 01:03.80–01:29.80
- **Hook (humiliation):** Noblewoman: "You are a maid."
- **Cliffhanger:** Lady Juliana: "I will return. You cannot stop the healer."
- **Why:** Cold-opens on the episode's biggest beat, then jumps to its closing cliffhanger.
- **Scores:** hook 4.0/5 · cliffhanger 4.0/5 · standalone 4.0/5

<details><summary>Transcript</summary>

```
(00:35.00) NOBLEWOMAN: You are a maid.
(00:37.00) NOBLEWOMAN: Not a physician. Not a lady.
(00:39.00) NOBLEWOMAN: And certainly not a woman whose opinion matters.
(00:43.20) LADY JULIANA: Yes, my lady.
--- cut ---
(01:03.80) [ACTION] Juliana slowly drops to her knees on the cold flagstones before the soot-filled fireplace.
(01:06.00) [ACTION] Prudence steps toward the noblewoman in distress, her hands clasped tightly.
(01:06.20) PRUDENCE: My lady—
(01:07.50) [ACTION] The noblewoman whips around sharply, thrusting the tip of her riding crop directly into Prudence's face.
(01:08.00) NOBLEWOMAN: Do you want the same punishment?
(01:10.60) PRUDENCE: No, my lady.
(01:12.50) [ACTION] Juliana grips a coarse scrubbing brush with both hands and begins vigorously scraping the thick black ash across the hearthstones.
(01:13.00) [SFX] Rhythmic, harsh rasping sound of bristles scraping against stone.
(01:15.00) NOBLEWOMAN: That is where clever little servants belong.
(01:18.60) LADY JULIANA: Let her think I am only a maid.
(01:21.20) [ACTION] Juliana pauses scrubbing. Her soot-caked fingers reach into the deep pocket of her apron, carefully feeling the worn leather cover of her mother's remedy 
```
</details>

## #5 · X27-28 · score 71.3 · 40s · cross_episode
- **Segments:** Ep 27 02:04.80–02:14.00 + Ep 28 01:45.60–02:16.70
- **Hook (reveal):** Lady Catherine: "She admits she has been giving the Duchess poison in secret!"
- **Cliffhanger:** Catherine: "...before he sends you to the gallows."
- **Why:** Episode 27's strongest hook, then straight to how episode 28 leaves it hanging.
- **Scores:** hook 5.0/5 · cliffhanger 4.0/5 · standalone 2.0/5

<details><summary>Transcript</summary>

```
(02:04.80) LADY CATHERINE: She admits she has been giving the Duchess poison in secret!
(02:08.70) JULIANA: That is not what I said!
(02:11.20) BLOND NOBLEMAN: Enough.
--- cut ---
(01:45.60) CATHERINE: ...the girl thrown out of her own family home.
(01:48.10) CATHERINE: The bride who married a penniless war veteran...
(01:51.10) CATHERINE: ...because no respectable man would have her.
(01:53.30) JULIANA: Do not speak about my husband!
(01:56.40) CATHERINE: And look at you now. Scrubbing fireplaces in my house.
(01:59.20) CATHERINE: What a magnificent fall, Lady Juliana.
(02:02.00) BLOND NOBLEMAN: Drag her to the wet cells beneath the south tower.
(02:05.00) CATHERINE: And this?
(02:05.90) CATHERINE: This book of weeds will hang her before the magistrate.
(02:09.10) JULIANA: That book is my mother's life's work!
(02:11.40) CATHERINE: Then perhaps you can explain every page to the magistrate...
(02:14.60) CATHERINE: ...before he sends you to the gallows.
```
</details>

## #6 · E36-A1-P1 · score 70.7 · 39s · multi
- **Segments:** Ep 36 01:57.50–02:07.50 + Ep 36 02:51.60–03:20.75
- **Hook (reveal):** Alexander: "You told them the truth!"
- **Cliffhanger:** A heavy, ominous orchestral swell builds to a thunderous cliffhanger sting and reverberat…
- **Why:** Cold-opens on the episode's biggest beat, then jumps to its closing cliffhanger.
- **Scores:** hook 4.0/5 · cliffhanger 5.0/5 · standalone 3.0/5

<details><summary>Transcript</summary>

```
(01:57.50) ALEXANDER: You told them the truth!
(01:59.80) ALEXANDER'S MOTHER: They called her a witch!
(02:03.80) ALEXANDER: Juliana... is in a cell?
--- cut ---
(02:51.60) ALEXANDER: They stole my home!
(02:54.20) ALEXANDER: And now they have taken Juliana!
(02:57.00) [ACTION] Close-up of Alexander's gloved hand clenching into a tight, leather-creaking fist.
(02:57.50) [SFX] The sharp, taut creak of leather straining under monstrous grip strength.
(03:00.00) [ACTION] Alexander stands framed in the doorway, staring out into the vast, snow-covered pine forest under the cold moonlight.
(03:02.00) ALEXANDER: Two days.
(03:04.50) ALEXANDER: Then they have two days to celebrate.
(03:09.50) ALEXANDER: Because before that wedding begins...
(03:13.00) ALEXANDER: ...their dead Duke is coming home.
(03:17.00) [ACTION] Alexander stares resolutely ahead into the dark, snowy woods as the camera holds on his grim, determined expression before cutting to black.
(03:17.00) [SFX] A heavy, ominous orchestral swell builds to a thunderous cliffhanger sting and reverberates into silence.
```
</details>

## #8 · E47-A1-P1 · score 68.9 · 30s · single
- **Segments:** Ep 47 01:14.80–01:44.50
- **Hook (violence):** Alexander: "Do it, Vaughn! Throw her past the estate perimeter!"
- **Cliffhanger:** Catherine: "You expect me to scrub floors before these commoners?"
- **Why:** Opens on a violence beat and cuts on an unresolved dialogue moment.
- **Scores:** hook 5.0/5 · cliffhanger 3.0/5 · standalone 3.0/5

<details><summary>Transcript</summary>

```
(01:15.20) ALEXANDER: Do it, Vaughn! Throw her past the estate perimeter!
(01:18.80) CATHERINE: Please, Alexander! Have mercy!
(01:22.20) JULIANA: Stop.
(01:24.00) ALEXANDER: Juliana, she tried to destroy you!
(01:26.70) JULIANA: She did.
(01:28.20) JULIANA: But Ashbourne does not throw beggars into the mud.
(01:31.00) [ACTION] Juliana walks to a side bench, picks up a rough servant's apron and a heavy iron ring of keys, and turns back to face Catherine.
(01:31.50) JULIANA: If you seek shelter in this house, Catherine, you earn it.
(01:36.00) CATHERINE: You want me? As a guest?
(01:39.20) JULIANA: As a scullery maid.
(01:41.50) CATHERINE: You expect me to scrub floors before these commoners?
```
</details>

## #9 · E02-A1-P1 · score 67.9 · 31s · single
- **Segments:** Ep 2 01:16.50–01:47.40
- **Hook (humiliation):** Lady Juliana: "You abandoned a woman who trusted you..."
- **Cliffhanger:** Lady Juliana: "...but I will not leave it believing I was the one who should be ashamed."
- **Why:** Opens on a humiliation beat and cuts on an unresolved dialogue moment.
- **Scores:** hook 4.0/5 · cliffhanger 4.0/5 · standalone 3.0/5

<details><summary>Transcript</summary>

```
(01:16.50) LADY JULIANA: You abandoned a woman who trusted you...
(01:19.20) LADY JULIANA: ...because another woman promised you greater beauty and wealth.
(01:23.00) LADY JULIANA: Do not mistake my heartbreak for your victory, Gerald.
(01:26.80) LADY JULIANA: You wanted this entire chapel to believe that I was not worthy of you. But you have shown them something far more valuable.
(01:33.40) LADY JULIANA: You have shown them exactly what your word is worth.
(01:38.20) [ACTION] Juliana lifts her chin high, commanding the space with unassailable dignity.
(01:38.50) LADY JULIANA: I may leave this chapel without a husband...
(01:43.00) LADY JULIANA: ...but I will not leave it believing I was the one who should be ashamed.
```
</details>

## #10 · E35-A1-P1 · score 67.8 · 40s · multi
- **Segments:** Ep 35 00:59.50–01:11.00 + Ep 35 02:09.50–02:37.50
- **Hook (threat):** Alexander'S Mother: "They told me you died. They told me your entire regiment was destroyed."
- **Cliffhanger:** A sudden, ominous orchestral crescendo swells dramatically into silence.
- **Why:** Cold-opens on the episode's biggest beat, then jumps to its closing cliffhanger.
- **Scores:** hook 4.0/5 · cliffhanger 4.0/5 · standalone 3.0/5

<details><summary>Transcript</summary>

```
(00:59.50) ALEXANDER'S MOTHER: They told me you died. They told me your entire regiment was destroyed.
(01:08.50) ALEXANDER: Most of them were.
--- cut ---
(02:09.50) ALEXANDER'S MOTHER: Who?
(02:10.50) [ACTION] Alexander turns away toward the frosted window, staring out into the dark raging blizzard outside.
(02:11.00) ALEXANDER: I spent three years trying to find out.
(02:14.00) [ACTION] Alexander abruptly pushes away from the window, storming back toward the table with burning rage.
(02:14.00) ALEXANDER: The ambush was not an accident.
(02:17.00) ALEXANDER: Someone ordered my men to die.
(02:17.00) [ACTION] He leans heavily over the wooden table, looming close as his fury boils over.
(02:21.00) ALEXANDER: Someone wanted me erased.
(02:24.00) ALEXANDER'S MOTHER: Who?
(02:25.50) ALEXANDER: The men behind it... are the same men ruling Ashwood now.
(02:30.80) [SFX] A sudden, ominous orchestral crescendo swells dramatically into silence.
```
</details>

## #11 · E28-A1-P3 · score 66.5 · 46s · single
- **Segments:** Ep 28 01:04.90–01:51.00
- **Hook (humiliation):** Catherine: "...is the maid who claims to have discovered it."
- **Cliffhanger:** Catherine: "The bride who married a penniless war veteran..."
- **Why:** Opens on a humiliation beat and cuts on an unresolved dialogue moment.
- **Scores:** hook 4.0/5 · cliffhanger 4.0/5 · standalone 3.0/5

<details><summary>Transcript</summary>

```
(01:04.90) CATHERINE: ...is the maid who claims to have discovered it.
(01:07.20) BLOND NOBLEMAN: Take her away before she poisons the rest of this house.
(01:10.80) [ACTION] Catherine ruthlessly yanks the silver locket off Juliana's neck.
(01:11.20) JULIANA: No!
(01:12.20) CATHERINE: Where did a gutter rat like you find a silver locket?
(01:15.40) JULIANA: Give it back!
(01:16.80) JULIANA: It belonged to my mother!
(01:19.00) CATHERINE: A witch has no need for family heirlooms in the gallows.
(01:21.00) [SFX] Metallic clatter as the silver pendant bounces against the wooden baseboard.
(01:22.50) JULIANA: My mother's locket!
(01:28.00) [ACTION] Catherine lifts the heavy herbarium, dusting off the cover before opening its aged parchment pages.
(01:31.20) CATHERINE: Juliana...
(01:35.20) [ACTION] Juliana gasps in horror, realizing her secret identity has been laid bare.
(01:38.20) CATHERINE: Lady Juliana Ashcroft.
(01:41.50) CATHERINE: I knew I had seen those eyes before.
(01:44.20) CATHERINE: The disgraced daughter...
(01:45.60) CATHERINE: ...the girl thrown out of her own family home.
(01:48.10) CATHERINE: The bride who married a penniless war veteran...
```
</details>

## #13 · E07-A1-P1 · score 65.6 · 25s · single
- **Segments:** Ep 7 01:05.20–01:30.00
- **Hook (humiliation):** Gerald: "I have enough influence to make a beggar disappear."
- **Cliffhanger:** Gerald: "What are you staring at?"
- **Why:** Opens on a humiliation beat and cuts on an unresolved dialogue moment.
- **Scores:** hook 5.0/5 · cliffhanger 2.0/5 · standalone 4.0/5

<details><summary>Transcript</summary>

```
(01:05.60) GERALD: I have enough influence to make a beggar disappear.
(01:08.60) GERALD: And your husband?
(01:09.50) GERALD: Where is that beggar husband?
(01:10.00) [ACTION] The Scarred Bearded Man marches purposefully toward the cottage, carrying a heavy bundle of chopped firewood bound tightly with hemp cord.
(01:16.20) [SFX] A dull, heavy thud of timber striking the mud.
(01:21.50) [ACTION] Gerald freezes, his arrogant bravado instantly vanishing as cold dread overtakes his face.
(01:26.50) ARISTOCRATIC WOMAN: Gerald, don't let him frighten you.
(01:28.60) GERALD: What are you staring at?
```
</details>

## #14 · E46-A1-P2 · score 64.9 · 22s · single
- **Segments:** Ep 46 00:20.50–00:42.50
- **Hook (betrayal):** High Priest: "You married this woman as a nameless beggar..."
- **Cliffhanger:** High Priest: "The church married a vagrant to a ruined lady. It never married the Duke of Ashburton to …"
- **Why:** Opens on a betrayal beat and cuts on an unresolved dialogue moment.
- **Scores:** hook 3.0/5 · cliffhanger 5.0/5 · standalone 3.0/5

<details><summary>Transcript</summary>

```
(00:20.60) HIGH PRIEST: You married this woman as a nameless beggar...
(00:22.90) HIGH PRIEST: ...in a hedge ceremony no clerk in England ever recorded.
(00:26.80) HIGH PRIEST: Three years later, the beggar is revealed to be a Duke. The marriage does not rise with him.
(00:32.50) [ACTION] Juliana places her hand over Alexander's as he steps forward to shield her.
(00:34.30) ALEXANDER: She married the man... not the title.
(00:37.30) HIGH PRIEST: The church married a vagrant to a ruined lady. It never married the Duke of Ashburton to anyone.
```
</details>

## #15 · E27-A1-P1 · score 64.8 · 55s · single
- **Segments:** Ep 27 01:13.80–02:08.40
- **Hook (humiliation):** Lady Catherine: "Medicine? You are a new maid."
- **Cliffhanger:** Lady Catherine: "She admits she has been giving the Duchess poison in secret!"
- **Why:** Opens on a humiliation beat and cuts on an unresolved dialogue moment.
- **Scores:** hook 4.0/5 · cliffhanger 4.0/5 · standalone 3.0/5

<details><summary>Transcript</summary>

```
(01:13.80) JULIANA: Medicine.
(01:15.20) LADY CATHERINE: Medicine? You are a new maid.
(01:18.10) LADY CATHERINE: Who permitted you to give medicine to the Duchess?
(01:21.00) JULIANA: No one.
(01:23.60) LADY CATHERINE: Then you administered it without permission.
(01:26.50) JULIANA: Because she was dying!
(01:28.20) BLOND NOBLEMAN: And you decided you knew better than every physician in this house?
(01:33.30) JULIANA: The physicians were not saving her!
(01:35.30) BLOND NOBLEMAN: My aunt has been wasting away for months.
(01:38.80) BLOND NOBLEMAN: And now we find an unknown maid alone beside her bed...
(01:44.20) BLOND NOBLEMAN: ...holding a substance no one authorized her to give.
(01:48.30) JULIANA: It is an antidote.
(01:50.30) LADY CATHERINE: An antidote to what?
(01:53.20) BLOND NOBLEMAN: Answer her.
(01:55.10) JULIANA: Poison.
(01:58.70) BLOND NOBLEMAN: Poison.
(02:00.40) JULIANA: Someone has been poisoning Her Grace.
(02:03.10) LADY CATHERINE: You hear that?!
(02:04.80) LADY CATHERINE: She admits she has been giving the Duchess poison in secret!
```
</details>
