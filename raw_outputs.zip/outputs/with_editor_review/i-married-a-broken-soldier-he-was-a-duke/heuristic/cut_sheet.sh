#!/usr/bin/env bash
# Promo cut sheet: run in the folder with the episode videos.
# Expected video names: episode-001.mp4, episode-002.mp4, ... (rename your files, or edit the names in the commands below)
# Times come from the screenplay; nudge by a few frames in your editor if needed.
set -e
mkdir -p promos

# #1  38s  score 87.0  |  Lady In Gold Gown: "Because he is marrying me."
ffmpeg -y -loglevel error -ss 39.10 -to 50.40 -i "episode-001.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_01_E01-A1-P1_part1.mp4"
ffmpeg -y -loglevel error -ss 111.10 -to 137.50 -i "episode-001.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_01_E01-A1-P1_part2.mp4"
printf "%s\n" "file 'promo_01_E01-A1-P1_part1.mp4'" "file 'promo_01_E01-A1-P1_part2.mp4'" > "promos/promo_01_E01-A1-P1.txt"
(cd promos && ffmpeg -y -loglevel error -f concat -safe 0 -i "promo_01_E01-A1-P1.txt" -c copy "promo_01_E01-A1-P1.mp4" && rm "promo_01_E01-A1-P1_part1.mp4" "promo_01_E01-A1-P1_part2.mp4" "promo_01_E01-A1-P1.txt")

# #2  32s  score 84.5  |  Prudence: "Lady Juliana! Please! You have to help me, Toby is dying!"
ffmpeg -y -loglevel error -ss 3.50 -to 35.80 -i "episode-021.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_02_E21-A1-P1_part1.mp4"
mv "promos/promo_02_E21-A1-P1_part1.mp4" "promos/promo_02_E21-A1-P1.mp4"

# #3  32s  score 83.1  |  The Thug with Cap violently shoves Juliana back with both hands; she c
ffmpeg -y -loglevel error -ss 47.40 -to 56.50 -i "episode-015.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_03_E15-A1-P1_part1.mp4"
ffmpeg -y -loglevel error -ss 63.50 -to 86.00 -i "episode-015.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_03_E15-A1-P1_part2.mp4"
printf "%s\n" "file 'promo_03_E15-A1-P1_part1.mp4'" "file 'promo_03_E15-A1-P1_part2.mp4'" > "promos/promo_03_E15-A1-P1.txt"
(cd promos && ffmpeg -y -loglevel error -f concat -safe 0 -i "promo_03_E15-A1-P1.txt" -c copy "promo_03_E15-A1-P1.mp4" && rm "promo_03_E15-A1-P1_part1.mp4" "promo_03_E15-A1-P1_part2.mp4" "promo_03_E15-A1-P1.txt")

# #4  36s  score 74.7  |  Noblewoman: "You are a maid."
ffmpeg -y -loglevel error -ss 35.00 -to 45.50 -i "episode-024.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_04_E24-A1-P1_part1.mp4"
ffmpeg -y -loglevel error -ss 63.80 -to 89.80 -i "episode-024.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_04_E24-A1-P1_part2.mp4"
printf "%s\n" "file 'promo_04_E24-A1-P1_part1.mp4'" "file 'promo_04_E24-A1-P1_part2.mp4'" > "promos/promo_04_E24-A1-P1.txt"
(cd promos && ffmpeg -y -loglevel error -f concat -safe 0 -i "promo_04_E24-A1-P1.txt" -c copy "promo_04_E24-A1-P1.mp4" && rm "promo_04_E24-A1-P1_part1.mp4" "promo_04_E24-A1-P1_part2.mp4" "promo_04_E24-A1-P1.txt")

# #5  40s  score 71.3  |  Lady Catherine: "She admits she has been giving the Duchess poison in 
ffmpeg -y -loglevel error -ss 124.80 -to 134.00 -i "episode-027.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_05_X27-28_part1.mp4"
ffmpeg -y -loglevel error -ss 105.60 -to 136.70 -i "episode-028.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_05_X27-28_part2.mp4"
printf "%s\n" "file 'promo_05_X27-28_part1.mp4'" "file 'promo_05_X27-28_part2.mp4'" > "promos/promo_05_X27-28.txt"
(cd promos && ffmpeg -y -loglevel error -f concat -safe 0 -i "promo_05_X27-28.txt" -c copy "promo_05_X27-28.mp4" && rm "promo_05_X27-28_part1.mp4" "promo_05_X27-28_part2.mp4" "promo_05_X27-28.txt")

# #6  39s  score 70.7  |  Alexander: "You told them the truth!"
ffmpeg -y -loglevel error -ss 117.50 -to 127.50 -i "episode-036.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_06_E36-A1-P1_part1.mp4"
ffmpeg -y -loglevel error -ss 171.60 -to 200.75 -i "episode-036.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_06_E36-A1-P1_part2.mp4"
printf "%s\n" "file 'promo_06_E36-A1-P1_part1.mp4'" "file 'promo_06_E36-A1-P1_part2.mp4'" > "promos/promo_06_E36-A1-P1.txt"
(cd promos && ffmpeg -y -loglevel error -f concat -safe 0 -i "promo_06_E36-A1-P1.txt" -c copy "promo_06_E36-A1-P1.mp4" && rm "promo_06_E36-A1-P1_part1.mp4" "promo_06_E36-A1-P1_part2.mp4" "promo_06_E36-A1-P1.txt")

# #8  30s  score 68.9  |  Alexander: "Do it, Vaughn! Throw her past the estate perimeter!"
ffmpeg -y -loglevel error -ss 74.80 -to 104.50 -i "episode-047.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_08_E47-A1-P1_part1.mp4"
mv "promos/promo_08_E47-A1-P1_part1.mp4" "promos/promo_08_E47-A1-P1.mp4"

# #9  31s  score 67.9  |  Lady Juliana: "You abandoned a woman who trusted you..."
ffmpeg -y -loglevel error -ss 76.50 -to 107.40 -i "episode-002.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_09_E02-A1-P1_part1.mp4"
mv "promos/promo_09_E02-A1-P1_part1.mp4" "promos/promo_09_E02-A1-P1.mp4"

# #10  40s  score 67.8  |  Alexander'S Mother: "They told me you died. They told me your entire r
ffmpeg -y -loglevel error -ss 59.50 -to 71.00 -i "episode-035.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_10_E35-A1-P1_part1.mp4"
ffmpeg -y -loglevel error -ss 129.50 -to 157.50 -i "episode-035.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_10_E35-A1-P1_part2.mp4"
printf "%s\n" "file 'promo_10_E35-A1-P1_part1.mp4'" "file 'promo_10_E35-A1-P1_part2.mp4'" > "promos/promo_10_E35-A1-P1.txt"
(cd promos && ffmpeg -y -loglevel error -f concat -safe 0 -i "promo_10_E35-A1-P1.txt" -c copy "promo_10_E35-A1-P1.mp4" && rm "promo_10_E35-A1-P1_part1.mp4" "promo_10_E35-A1-P1_part2.mp4" "promo_10_E35-A1-P1.txt")

# #11  46s  score 66.5  |  Catherine: "...is the maid who claims to have discovered it."
ffmpeg -y -loglevel error -ss 64.90 -to 111.00 -i "episode-028.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_11_E28-A1-P3_part1.mp4"
mv "promos/promo_11_E28-A1-P3_part1.mp4" "promos/promo_11_E28-A1-P3.mp4"

# #13  25s  score 65.6  |  Gerald: "I have enough influence to make a beggar disappear."
ffmpeg -y -loglevel error -ss 65.20 -to 90.00 -i "episode-007.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_13_E07-A1-P1_part1.mp4"
mv "promos/promo_13_E07-A1-P1_part1.mp4" "promos/promo_13_E07-A1-P1.mp4"

# #14  22s  score 64.9  |  High Priest: "You married this woman as a nameless beggar..."
ffmpeg -y -loglevel error -ss 20.50 -to 42.50 -i "episode-046.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_14_E46-A1-P2_part1.mp4"
mv "promos/promo_14_E46-A1-P2_part1.mp4" "promos/promo_14_E46-A1-P2.mp4"

# #15  55s  score 64.8  |  Lady Catherine: "Medicine? You are a new maid."
ffmpeg -y -loglevel error -ss 73.80 -to 128.40 -i "episode-027.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_15_E27-A1-P1_part1.mp4"
mv "promos/promo_15_E27-A1-P1_part1.mp4" "promos/promo_15_E27-A1-P1.mp4"

echo "Done: $(ls promos/*.mp4 | wc -l) promos in ./promos"