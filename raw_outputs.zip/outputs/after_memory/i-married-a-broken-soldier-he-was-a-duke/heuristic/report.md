# Promos — I Married a Broken Soldier. He was a Duke
Model: `heuristic` · candidates: 98 · top list: 15

## #1 · E04-A1-P2 · score 66.7 · 31s · single
- **Segments:** Ep 4 00:05.00–00:36.00
- **Hook (humiliation):** Gerald: "A penniless nobody for a discarded bride."
- **Cliffhanger:** Mysterious Bearded Man: "A woman who was betrayed."
- **Why:** Opens on a humiliation beat and cuts on an unresolved dialogue moment.
- **Scores:** hook 4.0/5 · cliffhanger 3.0/5 · standalone 3.0/5

<details><summary>Transcript</summary>

```
(00:05.00) GERALD: A penniless nobody for a discarded bride.
(00:07.80) [ACTION] Clarissa giggles spitefully, lowering her gloved hand to gloat.
(00:09.00) CLARISSA: How fitting.
(00:10.60) CLARISSA: You have finally found a man as worthless as everyone thinks you are.
(00:15.50) [ACTION] Juliana closes her eyes briefly and releases a steadying breath.
(00:20.00) JULIANA: You don't even know me.
(00:23.50) JULIANA: You heard what they think I am.
(00:25.90) JULIANA: Why would you offer me your name?
(00:28.00) MYSTERIOUS BEARDED MAN: Because I know what I see.
(00:32.10) JULIANA: And what do you see?
(00:34.00) MYSTERIOUS BEARDED MAN: A woman who was betrayed.
```
</details>

## #2 · E25-A1-P2 · score 65.4 · 54s · single
- **Segments:** Ep 25 01:19.50–02:13.80
- **Hook (threat):** Juliana: "Poison."
- **Cliffhanger:** Alexander: "Because you were standing inside a house where someone is poisoning a woman... and you ne…"
- **Why:** Opens on a threat beat and cuts on an unresolved dialogue moment.
- **Scores:** hook 4.0/5 · cliffhanger 3.0/5 · standalone 4.0/5

<details><summary>Transcript</summary>

```
(01:20.20) JULIANA: Poison.
(01:23.50) JULIANA: Arsenic.
(01:26.20) [ACTION] Alexander's hand drops to his side and clenches into a white-knuckled fist, the thick scar across his hand tightening with intense restraint.
(01:30.20) JULIANA: Someone has been giving it to her again and again. Small amounts. Enough to make her weaker without killing her quickly.
(01:40.40) JULIANA: I made her medicine. She was still barely conscious, but her breathing became easier.
(01:45.60) ALEXANDER: You treated her?
(01:47.20) JULIANA: Yes.
(01:48.40) ALEXANDER: Alone?
(01:49.80) JULIANA: With Prudence.
(01:52.20) ALEXANDER: Will you be going there again?
(01:55.20) JULIANA: I have to.
(01:57.50) JULIANA: She is still sick. I cannot leave her there.
(01:57.50) [ACTION] Juliana places her gentle hand against Alexander's broad chest, trying to soothe his rising anger.
(02:01.00) [ACTION] Alexander takes both of her hands into his own, gripping them tightly.
(02:05.80) JULIANA: Alexander... why are you so angry?
(02:08.20) ALEXANDER: Because you were standing inside a house where someone is poisoning a woman... and you never told me.
```
</details>

## #3 · X11-12 · score 65.4 · 42s · cross_episode
- **Segments:** Ep 11 00:29.30–00:41.10 + Ep 12 00:57.30–01:27.21
- **Hook (betrayal):** Gerald: "Of course you would defend him. You married a beggar!"
- **Cliffhanger:** Juliana locks eyes with Clarissa without flinching as the scene freezes on her brave, sac…
- **Why:** Episode 11's strongest hook, then straight to how episode 12 leaves it hanging.
- **Scores:** hook 5.0/5 · cliffhanger 3.0/5 · standalone 2.0/5

<details><summary>Transcript</summary>

```
(00:29.30) GERALD: Of course you would defend him. You married a beggar!
(00:33.00) ALEXANDER: Choose your next words carefully.
(00:35.10) GERALD: You hear that? He threatens me again!
(00:37.40) CONSTABLE: I have received a complaint of theft.
(00:39.70) JULIANA: A complaint is not proof.
--- cut ---
(00:57.30) CLARISSA: You will retrieve it with your bare hands before the magistrate arrives.
(01:00.80) GERALD: A lady's hands will be shredded to ribbons!
(01:03.30) CLARISSA: Do it, and we withdraw the charges.
(01:05.40) CLARISSA: Fail, or refuse, and your husband hangs from the gallows.
(01:09.60) [ACTION] Alexander rests his scarred hand reassuringly on Juliana's shoulder, leaning in toward her.
(01:09.80) ALEXANDER: Juliana, no. Do not let them hurt you. I can handle the law.
(01:14.20) [ACTION] Juliana clutches the front of her rustic grey dress, her breathing trembling.
(01:15.30) JULIANA: I am not letting them take you.
(01:21.50) [ACTION] Juliana turns her head sharply back toward Clarissa, her expression hardening with fierce resolution.
(01:22.80) JULIANA: Tell me where the garden is.
(01:24.70) [ACTION] Juliana locks eyes with Clarissa without flinching as the scene fre
```
</details>

## #4 · E22-A1-P1 · score 63.5 · 33s · single
- **Segments:** Ep 22 00:36.20–01:09.50
- **Hook (humiliation):** Lady Juliana: "Today, I am only a maid."
- **Cliffhanger:** Housekeeper: "And can you keep your eyes and ears where they belong?"
- **Why:** Opens on a humiliation beat and cuts on an unresolved dialogue moment.
- **Scores:** hook 3.0/5 · cliffhanger 3.0/5 · standalone 4.0/5

<details><summary>Transcript</summary>

```
(00:37.00) LADY JULIANA: Today, I am only a maid.
(00:39.80) [ACTION] Prudence opens the heavy wooden service door, and both women step inside into the dark servants' corridor as the door shuts firmly behind them.
(00:41.50) [SFX] Heavy wooden latch clicks shut with a thud.
(00:43.00) HOUSEKEEPER: Prudence.
(00:44.30) HOUSEKEEPER: Who is this?
(00:46.00) PRUDENCE: Julian, ma'am. New help for the winter cleaning.
(00:49.50) HOUSEKEEPER: She looks soft.
(00:51.80) [ACTION] Close-up on Lady Juliana's hands gripping the iron handle of the wooden wash bucket firmly.
(00:52.80) LADY JULIANA: I can work, ma'am.
(00:56.00) HOUSEKEEPER: Can you scrub stone?
(00:58.50) LADY JULIANA: Yes, ma'am.
(01:00.20) HOUSEKEEPER: Carry coal?
(01:02.50) LADY JULIANA: Yes, ma'am.
(01:06.00) HOUSEKEEPER: And can you keep your eyes and ears where they belong?
```
</details>

## #5 · E29-A1-P1 · score 63.5 · 39s · multi
- **Segments:** Ep 29 00:44.40–00:53.60 + Ep 29 01:25.70–01:55.50
- **Hook (threat):** Juliana: "You cannot just destroy it!"
- **Cliffhanger:** Close-up of the dungeon's massive iron portcullis bars dropping down with finality.
- **Why:** Cold-opens on the episode's biggest beat, then jumps to its closing cliffhanger.
- **Scores:** hook 5.0/5 · cliffhanger 2.0/5 · standalone 3.0/5

<details><summary>Transcript</summary>

```
(00:44.40) JULIANA: You cannot just destroy it!
(00:47.30) CATHERINE: I can burn it.
(00:50.10) CATHERINE: And when they find your corpse at the end of the rope...
--- cut ---
(01:25.70) JULIANA: Please!
(01:26.50) [SFX] The heavy iron door slams shut with a deafening metallic thud, and the massive exterior bolt grates locked.
(01:29.50) [ACTION] Juliana trembles uncontrollably, her fingers digging into the collar of her rustic dress as terror washes over her.
(01:34.20) JULIANA: Mother...
(01:37.30) JULIANA: I have done nothing!
(01:39.70) JULIANA: I saved her! I healed her!
(01:42.50) [SFX] Muffled, dull metallic clanging reverberates as Juliana hammers against the iron door.
(01:42.60) JULIANA: I saved the Duchess!
(01:46.50) JULIANA: They took my mother's ledger...
(01:49.00) JULIANA: They took her locket. But they will not take Alexander from me.
(01:52.80) [SFX] A heavy iron portcullis crashes down with a massive echoing bang.
```
</details>

## #6 · E30-A1-P1 · score 63.5 · 39s · multi
- **Segments:** Ep 30 00:33.60–00:43.80 + Ep 30 02:02.40–02:31.21
- **Hook (threat):** Elder Nobleman: "Then make certain she isn't! A peasant weed, Rupert! You do not store weeds in your cella…"
- **Cliffhanger:** Juliana clutches a rough burlap rag to her trembling chest, her tear-stained face lifting…
- **Why:** Cold-opens on the episode's biggest beat, then jumps to its closing cliffhanger.
- **Scores:** hook 5.0/5 · cliffhanger 2.0/5 · standalone 3.0/5

<details><summary>Transcript</summary>

```
(00:33.60) ELDER NOBLEMAN: Then make certain she isn't! A peasant weed, Rupert! You do not store weeds in your cellar, you burn them!
(00:41.80) RUPERT: What are you suggesting?
--- cut ---
(02:02.40) ELDER NOBLEMAN: She goes before the magistrate tomorrow.
(02:05.50) CATHERINE: She will hang. A perfect solution. The town will cheer as the witch's disgraced daughter faces the noose.
(02:14.10) RUPERT: I will write the arrest warrant myself.
(02:17.50) ELDER NOBLEMAN: Tomorrow, she stops being a prisoner. She becomes a witch.
(02:24.50) [SFX] Echoing, hollow water droplets splashing into dark pools beneath stone vaults, accompanied by a somber orchestral swell.
(02:28.50) [ACTION] Juliana clutches a rough burlap rag to her trembling chest, her tear-stained face lifting upward in dread and fragile hope as the frame holds, cutting abruptly to black.
```
</details>

## #7 · E27-A1-P2 · score 62.5 · 26s · single
- **Segments:** Ep 27 02:04.60–02:30.50
- **Hook (reveal):** Lady Catherine: "She admits she has been giving the Duchess poison in secret!"
- **Cliffhanger:** Extreme close-up of Juliana's wide, terrified eyes as she realizes the deadly trap closin…
- **Why:** Opens on a reveal beat and cuts on an unresolved camera moment.
- **Scores:** hook 5.0/5 · cliffhanger 2.0/5 · standalone 3.0/5

<details><summary>Transcript</summary>

```
(02:04.80) LADY CATHERINE: She admits she has been giving the Duchess poison in secret!
(02:08.70) JULIANA: That is not what I said!
(02:11.20) BLOND NOBLEMAN: Enough.
(02:14.80) [ACTION] The Blond Nobleman takes the medicine vial from Juliana's grasp, inspecting it under the candlelight.
(02:16.20) BLOND NOBLEMAN: An unknown servant enters a restricted chamber.
(02:19.60) BLOND NOBLEMAN: She secretly administers an unidentified substance to a helpless woman.
(02:24.00) BLOND NOBLEMAN: Take her.
(02:25.00) [ACTION] The guard twists Juliana around and drags her forcibly toward the doorway as she struggles against his grip.
```
</details>

## #8 · E28-A1-P2 · score 62.5 · 50s · single
- **Segments:** Ep 28 00:15.20–01:04.80
- **Hook (threat):** Juliana: "I did not poison her! Look at her eyes, the fever has broken!"
- **Cliffhanger:** Catherine: "How convenient that the only person who can prove the poison exists..."
- **Why:** Opens on a threat beat and cuts on an unresolved dialogue moment.
- **Scores:** hook 4.0/5 · cliffhanger 4.0/5 · standalone 2.0/5

<details><summary>Transcript</summary>

```
(00:15.30) JULIANA: I did not poison her! Look at her eyes, the fever has broken!
(00:18.90) BLOND NOBLEMAN: A clever story, girl.
(00:20.40) BLOND NOBLEMAN: But the guards know how to extract the truth.
(00:24.80) DOWAGER DUCHESS: Rupert...
(00:26.70) DOWAGER DUCHESS: Stop this!
(00:28.80) DOWAGER DUCHESS: She is innocent.
(00:30.80) DOWAGER DUCHESS: She saved me!
(00:33.20) JULIANA: Your Grace...
(00:35.00) DOWAGER DUCHESS: I know what happened to me!
(00:38.20) DOWAGER DUCHESS: I was poisoned!
(00:40.30) DOWAGER DUCHESS: And you... you knew!
(00:43.60) DOWAGER DUCHESS: Catherine knew!
(00:45.60) DOWAGER DUCHESS: They have been—
(00:46.80) [ACTION] The Duchess collapses back onto the pillows, coughing violently and clutching her chest.
(00:48.20) JULIANA: Let me help her!
(00:49.50) JULIANA: She's still weak, you cannot leave her like this!
(00:52.80) BLOND NOBLEMAN: You see?
(00:54.00) BLOND NOBLEMAN: The poison has clearly damaged her mind.
(00:57.00) DOWAGER DUCHESS: I am not delusional!
(00:58.60) BLOND NOBLEMAN: Of course you are not.
(01:00.10) BLOND NOBLEMAN: You are merely confused.
(01:01.60) CATHERINE: How convenient that the only person who can prove the poison exists.
```
</details>

## #9 · E21-A1-P2 · score 61.7 · 22s · single
- **Segments:** Ep 21 00:31.00–00:53.00
- **Hook (threat):** Prudence: "He is only seven! If you do not come, he will die! You are his only hope, Lady Juliana!"
- **Cliffhanger:** Prudence: "Yes! Right away, I will get it!"
- **Why:** Opens on a threat beat and cuts on an unresolved dialogue moment.
- **Scores:** hook 5.0/5 · cliffhanger 2.0/5 · standalone 3.0/5

<details><summary>Transcript</summary>

```
(00:31.00) [ACTION] Prudence drops desperately to her knees onto the hay-strewn barn floor, clasping her hands in tearful supplication.
(00:31.00) PRUDENCE: He is only seven! If you do not come, he will die! You are his only hope, Lady Juliana!
(00:35.80) [ACTION] Lady Juliana immediately reaches down and pulls Prudence firmly back to her feet, then turns to snatch her heavy leather-bound herbal ledger from the wooden workbench.
(00:35.90) LADY JULIANA: Stand up. Sinking to your knees will not save him. Let me grab my ledger. We go now.
(00:40.50) [ACTION] Lady Juliana clutches the thick book to her chest as she and Prudence sprint swiftly through the village.
(00:42.80) [SFX] Heavy, raspy chest coughs echoing in the small room, accompanied by crackling hearth fire.
(00:45.50) [ACTION] Lady Juliana rushes in, sets the ledger on the rustic wooden table, and quickly flips open the pages.
(00:47.30) LADY JULIANA: His skin is burning hot.
(00:48.80) [ACTION] Lady Juliana places her bandaged hand against Toby's flushed, sweating forehead as he wheezes painfully.
(00:48.90) LADY JULIANA: Prudence, fetch hot water immediately!
(00:51.20) PRUDENCE: Yes! Right away, I will get it!
```
</details>

## #10 · E46-A1-P3 · score 60.3 · 48s · single
- **Segments:** Ep 46 00:37.00–01:25.50
- **Hook (betrayal):** High Priest: "The church married a vagrant to a ruined lady. It never married the Duke of Ashburton to …"
- **Cliffhanger:** Juliana: "God married us, Father! You are just angry no one asked you first!"
- **Why:** Opens on a betrayal beat and cuts on an unresolved dialogue moment.
- **Scores:** hook 4.0/5 · cliffhanger 3.0/5 · standalone 3.0/5

<details><summary>Transcript</summary>

```
(00:37.30) HIGH PRIEST: The church married a vagrant to a ruined lady. It never married the Duke of Ashburton to anyone.
(00:42.80) HIGH PRIEST: No Crown license was sought, because no one thought to ask leave for a Duke to marry.
(00:47.10) HIGH PRIEST: No licensed clergyman presided...
(00:49.00) HIGH PRIEST: ...because a frightened village priest has no authority to bind a peer.
(00:52.20) HIGH PRIEST: And no clerk in London ever entered your name in the Royal register, because as far as the Crown knew, Alexander Ashburton was already dead.
(00:58.50) JULIANA: I didn't ask this church for permission to survive, Father.
(01:02.90) JULIANA: I won't ask it for permission to love.
(01:06.80) HIGH PRIEST: Love doesn't make a Duchess, girl. Paper does.
(01:11.40) JULIANA: Then look at this floor honestly, for once.
(01:14.40) JULIANA: A church called me unworthy.
(01:16.80) JULIANA: A church chained me.
(01:18.10) JULIANA: Now a church calls my marriage a lie!
(01:21.10) JULIANA: God married us, Father! You are just angry no one asked you first!
```
</details>

## #11 · E23-A1-P1 · score 60.2 · 33s · multi
- **Segments:** Ep 23 01:22.00–01:31.00 + Ep 23 01:47.50–02:11.50
- **Hook (threat):** Prudence: "Poison?"
- **Cliffhanger:** Close-up on the brass door lever as it slowly rotates downward, and the heavy door cracks…
- **Why:** Cold-opens on the episode's biggest beat, then jumps to its closing cliffhanger.
- **Scores:** hook 4.0/5 · cliffhanger 2.0/5 · standalone 4.0/5

<details><summary>Transcript</summary>

```
(01:22.00) PRUDENCE: Poison?
(01:26.00) LADY JULIANA: Arsenic.
(01:28.00) [SFX] Sudden violent coughing and sputtering from the Duchess.
--- cut ---
(01:47.50) LADY JULIANA: The charcoal may help remove what is still inside her. We must act quickly.
(01:52.20) [SFX] Sudden muffled thump and heavy footsteps echoing from the hallway outside the door!
(01:58.80) PRUDENCE: Juliana... someone is coming.
(02:09.20) [SFX] Loud, metallic clack of the door latch turning, followed by the slow creak of wood hinges.
```
</details>

## #12 · E26-A1-P1 · score 59.5 · 41s · multi
- **Segments:** Ep 26 00:43.50–00:55.50 + Ep 26 01:30.80–01:59.50
- **Hook (threat):** Juliana: "If the guards hear us, we are both dead."
- **Cliffhanger:** Medium close-up of Juliana frozen in shock, her breath catching as the Duchess's desperat…
- **Why:** Cold-opens on the episode's biggest beat, then jumps to its closing cliffhanger.
- **Scores:** hook 4.0/5 · cliffhanger 2.0/5 · standalone 4.0/5

<details><summary>Transcript</summary>

```
(00:43.50) JULIANA: If the guards hear us, we are both dead.
(00:52.50) [ACTION] The Duchess clutches the blanket against her chest, her breathing quickening with dismay.
--- cut ---
(01:30.80) [ACTION] The Duchess's mouth hangs open in pure disbelief as she stares fixedly at Juliana's hand.
(01:36.00) DOWAGER DUCHESS: Your hand... Let me see your hand.
(01:40.50) JULIANA: Your Grace? What is wrong? You look as though you've seen a ghost.
(01:46.00) [ACTION] The Duchess reaches outward with trembling fingers, grasping frantically for Juliana.
(01:48.80) [SFX] A sudden sharp rustle of fabric as her fingers snap tight.
(01:49.20) DOWAGER DUCHESS: Do not move!
(01:51.00) DOWAGER DUCHESS: Where... where... Where did you get this ring? Speak to me!
```
</details>

## #13 · E25-A1-P1 · score 58.8 · 26s · single
- **Segments:** Ep 25 02:17.20–02:43.00
- **Hook (threat):** Alexander: "Worry? They struck you. They could have killed you."
- **Cliffhanger:** Medium two-shot as Alexander holds her gaze in the twilight shadows.
- **Why:** Opens on a threat beat and cuts on an unresolved camera moment.
- **Scores:** hook 4.0/5 · cliffhanger 2.0/5 · standalone 4.0/5

<details><summary>Transcript</summary>

```
(02:17.40) ALEXANDER: Worry? They struck you. They could have killed you.
(02:23.20) JULIANA: But they didn't.
(02:25.20) ALEXANDER: This time.
(02:27.00) JULIANA: I am being careful.
(02:29.00) JULIANA: I cannot abandon her.
(02:31.20) [ACTION] Alexander closes his eyes for a brief, agonizing second, exhaling deeply as he yields to her unshakeable conviction.
(02:33.80) ALEXANDER: Then tell me everything.
(02:37.40) ALEXANDER: Everything you saw.
```
</details>

## #14 · E04-A1-P1 · score 58.6 · 22s · single
- **Segments:** Ep 4 01:53.00–02:14.50
- **Hook (violence):** Gerald: "You have thrown yourself away!"
- **Cliffhanger:** Lady Ashcroft: "You are disowned!"
- **Why:** Opens on a violence beat and cuts on an unresolved dialogue moment.
- **Scores:** hook 5.0/5 · cliffhanger 2.0/5 · standalone 3.0/5

<details><summary>Transcript</summary>

```
(01:53.00) THE PRIEST: ...husband and wife!
(01:54.00) [SFX] Dramatic musical chord swelling.
(01:55.00) GERALD: You have thrown yourself away!
(01:57.00) GERALD: For a penniless nobody!
(02:00.50) JULIANA: I would rather choose my own life...
(02:03.00) JULIANA: ...than spend another moment begging for yours.
(02:06.00) [ACTION] Gerald recoils slightly, mouth agape.
(02:07.50) LADY ASHCROFT: Do not bring this man anywhere near Ashcroft Manor!
(02:12.00) LADY ASHCROFT: You are disowned!
```
</details>

## #15 · E14-A1-P1 · score 58.6 · 38s · single
- **Segments:** Ep 14 00:00.00–00:38.50
- **Hook (reveal):** Juliana's blood-streaked, mud-caked hand slowly uncurls amidst the thorns, revealing the …
- **Cliffhanger:** Alexander: "You should never have had to bleed for me."
- **Why:** Opens on a reveal beat and cuts on an unresolved dialogue moment.
- **Scores:** hook 3.0/5 · cliffhanger 3.0/5 · standalone 4.0/5

<details><summary>Transcript</summary>

```
(00:00.50) [ACTION] Juliana's blood-streaked, mud-caked hand slowly uncurls amidst the thorns, revealing the ornate emerald signet ring resting in her palm.
(00:01.00) [SFX] Eerie cold wind whistling over the briars with deep, atmospheric cello chords.
(00:07.70) JULIANA: I found it.
(00:10.50) JULIANA: Now release my husband.
(00:12.50) [ACTION] The Constable takes the ring from her bloodied fingers.
(00:14.20) [SFX] Sharp metallic click and clinking rattle of heavy iron handcuffs unlocking and falling away.
(00:14.50) [ACTION] The Constable unlocks the cuffs, freeing Alexander's large hands.
(00:16.80) ALEXANDER: Juliana.
(00:18.80) [ACTION] Alexander gently turns her palms up, his thumbs trembling as he inspects the deep, bleeding gashes gouged into her skin.
(00:23.10) ALEXANDER: What have they done to you?
(00:26.50) JULIANA: Nothing they didn't promise.
(00:29.80) JULIANA: Take me home.
(00:33.20) [ACTION] Alexander lifts Juliana bridal-style, wrapping his strong arms protectively around her as she rests against his shoulder.
(00:35.80) ALEXANDER: You should never have had to bleed for me.
```
</details>
