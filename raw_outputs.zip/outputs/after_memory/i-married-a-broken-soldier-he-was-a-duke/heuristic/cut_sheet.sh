#!/usr/bin/env bash
# Promo cut sheet: run in the folder with the episode videos.
# Expected video names: episode-001.mp4, episode-002.mp4, ... (rename your files, or edit the names in the commands below)
# Times come from the screenplay; nudge by a few frames in your editor if needed.
set -e
mkdir -p promos

# #1  31s  score 66.7  |  Gerald: "A penniless nobody for a discarded bride."
ffmpeg -y -loglevel error -ss 5.00 -to 36.00 -i "episode-004.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_01_E04-A1-P2_part1.mp4"
mv "promos/promo_01_E04-A1-P2_part1.mp4" "promos/promo_01_E04-A1-P2.mp4"

# #2  54s  score 65.4  |  Juliana: "Poison."
ffmpeg -y -loglevel error -ss 79.50 -to 133.80 -i "episode-025.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_02_E25-A1-P2_part1.mp4"
mv "promos/promo_02_E25-A1-P2_part1.mp4" "promos/promo_02_E25-A1-P2.mp4"

# #3  42s  score 65.4  |  Gerald: "Of course you would defend him. You married a beggar!"
ffmpeg -y -loglevel error -ss 29.30 -to 41.10 -i "episode-011.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_03_X11-12_part1.mp4"
ffmpeg -y -loglevel error -ss 57.30 -to 87.21 -i "episode-012.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_03_X11-12_part2.mp4"
printf "%s\n" "file 'promo_03_X11-12_part1.mp4'" "file 'promo_03_X11-12_part2.mp4'" > "promos/promo_03_X11-12.txt"
(cd promos && ffmpeg -y -loglevel error -f concat -safe 0 -i "promo_03_X11-12.txt" -c copy "promo_03_X11-12.mp4" && rm "promo_03_X11-12_part1.mp4" "promo_03_X11-12_part2.mp4" "promo_03_X11-12.txt")

# #4  33s  score 63.5  |  Lady Juliana: "Today, I am only a maid."
ffmpeg -y -loglevel error -ss 36.20 -to 69.50 -i "episode-022.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_04_E22-A1-P1_part1.mp4"
mv "promos/promo_04_E22-A1-P1_part1.mp4" "promos/promo_04_E22-A1-P1.mp4"

# #5  39s  score 63.5  |  Juliana: "You cannot just destroy it!"
ffmpeg -y -loglevel error -ss 44.40 -to 53.60 -i "episode-029.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_05_E29-A1-P1_part1.mp4"
ffmpeg -y -loglevel error -ss 85.70 -to 115.50 -i "episode-029.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_05_E29-A1-P1_part2.mp4"
printf "%s\n" "file 'promo_05_E29-A1-P1_part1.mp4'" "file 'promo_05_E29-A1-P1_part2.mp4'" > "promos/promo_05_E29-A1-P1.txt"
(cd promos && ffmpeg -y -loglevel error -f concat -safe 0 -i "promo_05_E29-A1-P1.txt" -c copy "promo_05_E29-A1-P1.mp4" && rm "promo_05_E29-A1-P1_part1.mp4" "promo_05_E29-A1-P1_part2.mp4" "promo_05_E29-A1-P1.txt")

# #6  39s  score 63.5  |  Elder Nobleman: "Then make certain she isn't! A peasant weed, Rupert! 
ffmpeg -y -loglevel error -ss 33.60 -to 43.80 -i "episode-030.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_06_E30-A1-P1_part1.mp4"
ffmpeg -y -loglevel error -ss 122.40 -to 151.21 -i "episode-030.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_06_E30-A1-P1_part2.mp4"
printf "%s\n" "file 'promo_06_E30-A1-P1_part1.mp4'" "file 'promo_06_E30-A1-P1_part2.mp4'" > "promos/promo_06_E30-A1-P1.txt"
(cd promos && ffmpeg -y -loglevel error -f concat -safe 0 -i "promo_06_E30-A1-P1.txt" -c copy "promo_06_E30-A1-P1.mp4" && rm "promo_06_E30-A1-P1_part1.mp4" "promo_06_E30-A1-P1_part2.mp4" "promo_06_E30-A1-P1.txt")

# #7  26s  score 62.5  |  Lady Catherine: "She admits she has been giving the Duchess poison in 
ffmpeg -y -loglevel error -ss 124.60 -to 150.50 -i "episode-027.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_07_E27-A1-P2_part1.mp4"
mv "promos/promo_07_E27-A1-P2_part1.mp4" "promos/promo_07_E27-A1-P2.mp4"

# #8  50s  score 62.5  |  Juliana: "I did not poison her! Look at her eyes, the fever has broken
ffmpeg -y -loglevel error -ss 15.20 -to 64.80 -i "episode-028.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_08_E28-A1-P2_part1.mp4"
mv "promos/promo_08_E28-A1-P2_part1.mp4" "promos/promo_08_E28-A1-P2.mp4"

# #9  22s  score 61.7  |  Prudence: "He is only seven! If you do not come, he will die! You are 
ffmpeg -y -loglevel error -ss 31.00 -to 53.00 -i "episode-021.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_09_E21-A1-P2_part1.mp4"
mv "promos/promo_09_E21-A1-P2_part1.mp4" "promos/promo_09_E21-A1-P2.mp4"

# #10  48s  score 60.3  |  High Priest: "The church married a vagrant to a ruined lady. It never 
ffmpeg -y -loglevel error -ss 37.00 -to 85.50 -i "episode-046.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_10_E46-A1-P3_part1.mp4"
mv "promos/promo_10_E46-A1-P3_part1.mp4" "promos/promo_10_E46-A1-P3.mp4"

# #11  33s  score 60.2  |  Prudence: "Poison?"
ffmpeg -y -loglevel error -ss 82.00 -to 91.00 -i "episode-023.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_11_E23-A1-P1_part1.mp4"
ffmpeg -y -loglevel error -ss 107.50 -to 131.50 -i "episode-023.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_11_E23-A1-P1_part2.mp4"
printf "%s\n" "file 'promo_11_E23-A1-P1_part1.mp4'" "file 'promo_11_E23-A1-P1_part2.mp4'" > "promos/promo_11_E23-A1-P1.txt"
(cd promos && ffmpeg -y -loglevel error -f concat -safe 0 -i "promo_11_E23-A1-P1.txt" -c copy "promo_11_E23-A1-P1.mp4" && rm "promo_11_E23-A1-P1_part1.mp4" "promo_11_E23-A1-P1_part2.mp4" "promo_11_E23-A1-P1.txt")

# #12  41s  score 59.5  |  Juliana: "If the guards hear us, we are both dead."
ffmpeg -y -loglevel error -ss 43.50 -to 55.50 -i "episode-026.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_12_E26-A1-P1_part1.mp4"
ffmpeg -y -loglevel error -ss 90.80 -to 119.50 -i "episode-026.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_12_E26-A1-P1_part2.mp4"
printf "%s\n" "file 'promo_12_E26-A1-P1_part1.mp4'" "file 'promo_12_E26-A1-P1_part2.mp4'" > "promos/promo_12_E26-A1-P1.txt"
(cd promos && ffmpeg -y -loglevel error -f concat -safe 0 -i "promo_12_E26-A1-P1.txt" -c copy "promo_12_E26-A1-P1.mp4" && rm "promo_12_E26-A1-P1_part1.mp4" "promo_12_E26-A1-P1_part2.mp4" "promo_12_E26-A1-P1.txt")

# #13  26s  score 58.8  |  Alexander: "Worry? They struck you. They could have killed you."
ffmpeg -y -loglevel error -ss 137.20 -to 163.00 -i "episode-025.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_13_E25-A1-P1_part1.mp4"
mv "promos/promo_13_E25-A1-P1_part1.mp4" "promos/promo_13_E25-A1-P1.mp4"

# #14  22s  score 58.6  |  Gerald: "You have thrown yourself away!"
ffmpeg -y -loglevel error -ss 113.00 -to 134.50 -i "episode-004.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_14_E04-A1-P1_part1.mp4"
mv "promos/promo_14_E04-A1-P1_part1.mp4" "promos/promo_14_E04-A1-P1.mp4"

# #15  38s  score 58.6  |  Juliana's blood-streaked, mud-caked hand slowly uncurls amidst the tho
ffmpeg -y -loglevel error -ss 0.00 -to 38.50 -i "episode-014.mp4" -c:v libx264 -preset veryfast -crf 20 -c:a aac "promos/promo_15_E14-A1-P1_part1.mp4"
mv "promos/promo_15_E14-A1-P1_part1.mp4" "promos/promo_15_E14-A1-P1.mp4"

echo "Done: $(ls promos/*.mp4 | wc -l) promos in ./promos"