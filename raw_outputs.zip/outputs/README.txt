RAW OUTPUTS — Promo Finder (Kuku AI Generalist, Problem 1)
Unedited results on the full input pack: "I Married a Broken Soldier. He was a Duke", all 50 episodes.
Produced by: python -m promo_finder run --data "<show folder>"   (free rule-based backend, no API)

i-married-a-broken-soldier-he-was-a-duke/heuristic/   main run
    promos_top.csv / .json        the posting list (top 15, ranked)
    all_candidates_ranked.json    every valid promo found (96), ranked
    report.md                     readable report with hook, cliffhanger, scores and transcript per promo
    quality_audit.json            input checks: missing episodes, bad timestamps, episodes without promos
    cut_sheet.sh                  ffmpeg commands to cut each promo from episode-001.mp4 ...
    run_log.txt                   per-episode log
with_editor_review/               same run after an editor approved 13 and rejected 2 (examples/editor_decisions.json)
after_memory/                     the next run: remembered clips pushed down, editor preferences applied

Contains short screenplay excerpts — confidential, do not publish.
